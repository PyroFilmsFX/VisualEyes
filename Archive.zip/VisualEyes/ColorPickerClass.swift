//
//  ColorPickerClass.swift
//  VisualEyes
//
//  Created by Justin on 12/20/16.
//  Copyright © 2016 adhoc. All rights reserved.
//

import Foundation


class ColorPickerClass {
    var redColor = Float()
    var greenColor = Float()
    var blueColor = Float()
    
}
